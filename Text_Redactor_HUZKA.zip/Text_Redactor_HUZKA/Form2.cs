﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Text_Redactor_HUZKA
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            string AssemblyProduct = "Текстовый редактор",
                  AssemblyVersion = "1.0.0",
                  AssemblyCompany = "HUZKA";
            // this.Text = String.Format("О {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Версия {0}", AssemblyVersion);
            this.labelCopyright.Text = "Лешан Даниил Ильич"; // AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.Description.Text = "Описание:\n Текстовой редактор"; //AssemblyDescription;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
